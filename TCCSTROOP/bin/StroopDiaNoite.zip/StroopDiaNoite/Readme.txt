verifique  os equipamentos se est�o na mesma rede wifi
Inicie aplica��o desktop
Inicie aplicativo mobile
conecte aplicaivo mobile ao desktop(usando nome do computador se n�o der pelo nome tente pelo ip de rede).
obs: para verificar o ip, 
	Crlt+R Digite "Cmd" executar.
    	Digite ipconfig- conex�o wifi

Preenchar o formulario e confirme
na tela do tablet vai ficar aparecendo aguardando ate iniciar o teste
click em iniciar. 
